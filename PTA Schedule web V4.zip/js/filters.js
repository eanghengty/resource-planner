// ─── Month Filter ─────────────────────────────────────────────────────────────
window._selectedMonths = new Set(); // empty = all selected

function monthKey(dateLabel) {
  // dateLabel like "07 Apr 2026" → "Apr 2026"
  const parts = dateLabel.split(' ');
  return parts.length >= 3 ? `${parts[1]} ${parts[2]}` : dateLabel;
}

function populateMonthFilter(dateCols) {
  const months = [...new Set(dateCols.map(dc => monthKey(dc.date)))];
  window._allMonths = months;
  window._selectedMonths = new Set(months);

  const container = document.getElementById('month-options');
  if (!container) return;
  container.innerHTML = months.map(m => `
    <label class="month-opt flex items-center gap-3 px-4 py-2 cursor-pointer select-none">
      <input type="checkbox" value="${m}" checked onchange="onMonthChange()"
        class="flex-shrink-0" />
      <span class="text-sm text-gray-700 font-medium">${m}</span>
    </label>`).join('');
  updateMonthBadge();
}

function onMonthChange() {
  const checkboxes = document.querySelectorAll('#month-options input[type=checkbox]');
  window._selectedMonths = new Set([...checkboxes].filter(c => c.checked).map(c => c.value));
  if (window._selectedMonths.size === 0) selectAllMonths();
  else { updateMonthBadge(); window._sitePage = 1; renderSites(); }
}

function selectAllMonths() {
  document.querySelectorAll('#month-options input[type=checkbox]').forEach(c => c.checked = true);
  window._selectedMonths = new Set(window._allMonths || []);
  updateMonthBadge();
  window._sitePage = 1;
  renderSites();
}

function updateMonthBadge() {
  const total  = (window._allMonths || []).length;
  const sel    = window._selectedMonths.size;
  const badge  = document.getElementById('month-active-count');
  if (!badge) return;
  if (sel < total) {
    badge.textContent = sel;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

function toggleMonthMenu() {
  document.getElementById('month-menu').classList.toggle('hidden');
}

// ─── Date Range Filter ────────────────────────────────────────────────────────
window._dateFrom = null;
window._dateTo   = null;

function toggleDateRangeMenu() {
  document.getElementById('daterange-menu').classList.toggle('hidden');
}

function onDateRangeChange() {
  window._dateFrom = document.getElementById('date-from').value || null;
  window._dateTo   = document.getElementById('date-to').value   || null;
  updateDateRangeLabel();
  window._sitePage = 1;
  renderSites();
}

function clearDateRange() {
  document.getElementById('date-from').value = '';
  document.getElementById('date-to').value   = '';
  window._dateFrom = null;
  window._dateTo   = null;
  updateDateRangeLabel();
  window._sitePage = 1;
  renderSites();
}

function updateDateRangeLabel() {
  const lbl = document.getElementById('daterange-label');
  const btn = document.getElementById('daterange-btn');
  if (!lbl || !btn) return;
  const from = window._dateFrom;
  const to   = window._dateTo;
  if (from || to) {
    const fStr = from ? from.slice(5).replace('-','/') : '…';
    const tStr = to   ? to.slice(5).replace('-','/')   : '…';
    lbl.textContent = `${fStr} – ${tStr}`;
    btn.classList.add('date-range-active');
  } else {
    lbl.textContent = 'Date Range';
    btn.classList.remove('date-range-active');
  }
}

// Returns true if site has at least one date within [_dateFrom, _dateTo]
function siteInDateRange(site) {
  const from = window._dateFrom;
  const to   = window._dateTo;
  if (!from && !to) return true;
  return (site.dateList || []).some(label => {
    const iso = dateLabelToISO(label);
    if (!iso) return false;
    if (from && iso < from) return false;
    if (to   && iso > to)   return false;
    return true;
  });
}

// Returns dateCols filtered to selected months AND date range
function activeDataCols() {
  const sel  = window._selectedMonths;
  const from = window._dateFrom;
  const to   = window._dateTo;
  const all  = window._dateCols || [];
  return all.filter(dc => {
    if (sel && sel.size > 0 && !sel.has(monthKey(dc.date))) return false;
    if (from || to) {
      const iso = dateLabelToISO(dc.date);
      if (from && iso < from) return false;
      if (to   && iso > to)   return false;
    }
    return true;
  });
}

// ─── Close dropdowns when clicking outside ────────────────────────────────────
document.addEventListener('click', e => {
  const wrapMonth = document.getElementById('month-wrapper');
  if (wrapMonth && !wrapMonth.contains(e.target))
    document.getElementById('month-menu')?.classList.add('hidden');

  const wrapDR = document.getElementById('daterange-wrapper');
  if (wrapDR && !wrapDR.contains(e.target))
    document.getElementById('daterange-menu')?.classList.add('hidden');

  const wrapGroup = document.getElementById('groupby-wrapper');
  if (wrapGroup && !wrapGroup.contains(e.target))
    document.getElementById('groupby-menu')?.classList.add('hidden');
});

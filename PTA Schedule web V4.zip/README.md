# Team Schedule Dashboard

A local, browser-based dashboard that reads a team schedule from an Excel (`.xlsx`) file and displays it as a live, interactive web app — no server, no database, no internet required (after first load).

---

## Screenshots

| Landing | Dashboard |
|---------|-----------|
| Open the file picker to get started | Sites panel, stats cards, and weekly schedule table |

---

## Features

- **Live Excel reading** — opens your `.xlsx` directly in the browser; no upload, no copy
- **Direct write-back** — renaming a job saves instantly back to the same file on disk (File System Access API)
- **Auto-resume** — remembers the last opened file via IndexedDB; reopens automatically on refresh
- **Unique Sites card** — shows the count of distinct site IDs (e.g. `E07`) active within the current filter window; updates live when the date range or month filter changes
- **Sites & Jobs panel**
  - Search by name
  - Filter by All / Multi-day / Single-day
  - Sort by name, start date, or duration
  - Group by Site ID, Start Date, or Status
  - Collapsible groups with pagination (20 groups per page)
  - Gap detection — flags non-consecutive date ranges
  - Edit job name inline and save back to Excel
  - **Group by Start Date** — date groups are scoped to the active filter window (dates outside the range are not shown); each group header shows site entry count and unique site ID count
  - "X sites found" label and the Unique Sites card always show the same count, computed from the same filtered list
- **Site detail modal** — click any site to see which employees are assigned per day, with an option to hide inactive days
- **Weekly schedule table** — full roster grid with colour-coded badges and week-grouping headers
- **Month filter** — show only selected months
- **Date range filter** — narrow to any custom date window; all counts update to reflect only the selected range
- **Dark sidebar UI** — inspired by modern SaaS dashboards

---

## Excel File Format

The dashboard expects your `.xlsx` to follow this layout:

| Row | Column A | Column B | Column C+ |
|-----|----------|----------|-----------|
| 1 | *(blank)* | *(blank)* | Date (e.g. `07 Apr 2026`) |
| 2 | *(blank)* | *(blank)* | Day name (e.g. `Mon`) |
| 3+ | Employee name | *(unused)* | Assignment text per day |

- **Columns C onward** are date columns. Each column represents one working day.
- **Rows 3 onward** are employee rows. Column A holds the employee's name.
- **Cell values** are free text (e.g. `R08 Cable Run`, `Standby`, `Public Holiday`, `L2 Training`).
- Cells with **merged headers** are supported — merged cells are expanded automatically.
- **Slash-separated site IDs** (e.g. `E17/E14 Cable Run`) are split into individual sites.

### Badge colour rules

| Category | Triggered when cell contains |
|----------|------------------------------|
| 🟡 Standby | `standby` |
| 🟢 Holiday | `public holiday` or `holiday` |
| 🔵 Training / Travel | `training`, `travel`, or `trianing` (typo-safe) |
| 🟩 Site Work | anything else with a valid site ID |
| ⬜ Empty | blank cell |

---

## Getting Started

### Requirements

- **Python 3** (recommended) **or Node.js** installed on your machine
- A modern browser (Chrome 86+ recommended for full read/write support)

### Run

Double-click **`launch_dashboard.bat`**.

This starts a local web server on port `8089` and opens `http://localhost:8089/dashboard.html` in your default browser automatically.

If Python is not found, it falls back to Node.js `http-server`.

```
launch_dashboard.bat
```

> **Why a local server?** The File System Access API and ES modules require an `http://` or `https://` origin. Opening `dashboard.html` directly as a `file://` URL will not work.

---

## Project Structure

```
Convert to HTML/
├── dashboard.html        # App shell — HTML structure only
├── launch_dashboard.bat  # One-click launcher (Python or Node)
├── test.xlsx             # Sample schedule file
│
├── css/
│   └── dashboard.css     # All styles (layout, sidebar, cards, modals)
│
└── js/
    ├── utils.js          # Pure helpers: categorise, getSiteId, expandSlashSites,
    │                     #   dateLabelToISO, showToast, makeCard
    ├── idb.js            # IndexedDB file-handle persistence
    ├── filters.js        # Month filter, date range filter, activeDataCols()
    ├── sites.js          # Sites panel: extractSites, renderSites, groups,
    │                     #   pagination, collapse, sort, groupBy;
    │                     #   renderSites() updates both "sites found" label and
    │                     #   the Unique Sites card from a single computed value
    ├── modal.js          # Site detail modal + Escape key handler
    ├── edit-job.js       # Edit job name modal + Excel write-back
    └── loader.js         # loadFile, schedule table render, resumeFile, auto-init
```

Scripts are loaded in dependency order in `dashboard.html`:

```
utils → idb → filters → sites → modal → edit-job → loader
```

---

## How It Works

1. **File open** — `loader.js` uses the [File System Access API](https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API) (`window.showOpenFilePicker`) to let the user pick a `.xlsx`. The file handle is stored in IndexedDB so the next page load can re-open the same file without prompting.

2. **Parsing** — [SheetJS (xlsx.js)](https://sheetjs.com/) reads the workbook. Merged cells are expanded so every cell in a merged range holds the origin value. Excel date serials are converted to `"DD Mon YYYY"` labels using UTC maths (avoids timezone drift).

3. **Rendering** — Three independent render passes:
   - `makeCard()` builds the Unique Sites summary card on initial load. After that, `renderSites()` owns the count: it computes `new Set(filtered.map(s => s.siteId)).size` — counting distinct site ID prefixes (e.g. `E07`) among the currently visible sites — and writes that single value to both the "X sites found" subtitle and the summary card, so they are always in sync.
   - `renderSites()` builds the collapsible, paginated sites panel. In **Group by Start Date** mode, `buildGroups()` intersects each site's full date list with `activeDataCols()` so only dates inside the active filter window generate groups.
   - The schedule table is built directly inside `loadFile()`

4. **Edit & save** — `saveEditJobName()` in `edit-job.js` patches the in-memory workbook, re-serialises it with `XLSX.write()`, and streams the bytes directly back to disk via the file handle's `createWritable()` — no download required.

---

## Browser Compatibility

| Feature | Chrome 86+ | Edge 86+ | Firefox | Safari 15.2+ |
|---------|-----------|----------|---------|--------------|
| View dashboard | ✅ | ✅ | ✅ | ✅ |
| Direct file save | ✅ | ✅ | ❌ | ✅ |
| Auto-resume | ✅ | ✅ | ❌ | ✅ |

On Firefox, the app falls back to a standard `<input type="file">` picker. Edits download as a new file instead of saving in-place.

---

## Dependencies (CDN, no install needed)

| Library | Version | Purpose |
|---------|---------|---------|
| [SheetJS](https://cdn.sheetjs.com/) | 0.18.5 | Read & write `.xlsx` files |
| [Tailwind CSS](https://tailwindcss.com/) | CDN | Utility classes for layout |
| [Inter](https://fonts.google.com/specimen/Inter) | Google Fonts | UI typography |

---

## Customisation

### Change the port

Edit line 9 of `launch_dashboard.bat`:

```bat
start "" http://localhost:8089/dashboard.html
python -m http.server 8089
```

Replace `8089` with any free port.

### Add or rename skip terms

In `js/sites.js`, the `skip` set controls which cell values are **excluded** from the Sites panel:

```js
const skip = new Set([
  'standby', 'public holiday', 'l2 training', 'travel wa + l2',
  'trianing (wah & tr) - vic', 'travel wa + l2 training', 'prep work', '', 'nan'
]);
```

Add any values you want suppressed from the sites list.

### Change the accent colour

The primary orange accent is defined once in `css/dashboard.css`. Search for `#F97316` and replace with your preferred colour. The sidebar dark background is `#0F172A`.

---

## Known Limitations

- Only the **first sheet** of the workbook is read.
- The schedule table renders **all date columns** at once — very wide files may require horizontal scrolling.
- Direct save requires the browser to have been granted **read/write** permission on the file (prompted once per browser session).
